module.exports = {
    configureWebpack: {
        resolve: {
            alias: {
                'views': '@/views',
                'network': "@/network",
                'router': "@/router",
                'assets': "@/assets",
                'common': "@/common",
                'components': "@/components",
            }
        }
    }
}