import Vue from 'vue'
import App from './App.vue'
import router from './router'

Vue.config.productionTip = false

//添加事件总线 用于监听总线事件
Vue.prototype.$bus = new Vue();

new Vue({
  router,
  render: function (h) { return h(App) },
}).$mount('#app')
