<template>
  <div>
    <nav-bar class="category-navbar">
      <span slot="center">商品分类</span>
    </nav-bar>
    <b-scroll>
      <ul>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
        <li>我爱中华</li>
      </ul>
    </b-scroll>
  </div>
</template>

<script>
import NavBar from "components/common/navbar/Navbar.vue";
import BScroll from "components/content/scroll/BScroll.vue";
export default {
  components: {
    NavBar,
    BScroll,
  },
};
</script>

<style>
.category-navbar {
  background-color: #ff5777;
  color: white;
}
</style>