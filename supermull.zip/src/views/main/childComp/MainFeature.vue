<template>
  <div class="feature">
    <img src="~assets/img/main/recommend_bg.jpg" />
  </div>
</template>

<script>
export default {};
</script>

<style>
.feature img {
  width: 100%;
}
</style>