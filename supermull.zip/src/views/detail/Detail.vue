<template>
  <div class="detail">
    <!-- 商品详情页导航栏 -->
    <detail-nav-bar />
    <!-- <b-scroll
      :probe-type="3"
      class="main-scrollContent"
      @contentScroll="contentScroll"
      ref="bsScroll"
    > -->
    <!-- 商品详情页轮播图 -->
    <detail-swiper :images="styleImage" class="detail-swiper" />
    <!-- 商品基础信息 -->
    <detail-base-info :goods="baseGoods" />
    <!-- 商品所在店铺信息 -->
    <detail-shop-info :shop="shop" />
    <!-- 商品详情展示 -->
    <detail-goods-info :detailInfo="detailInfo" />
    <!-- 商品参数 -->
    <detail-goods-param :paramInfo="goodsParam" />
    <!-- 用户评论 -->
    <detail-comment :comment="commentInfo" />
    <!-- 推荐商品 -->
    <goods-list :goodsItem="goodsList" />
    <!-- </b-scroll> -->

    <!-- 回到顶部 -->
    <back-top v-show="isShowBackTop" @click.native="goBackTop" />
  </div>
</template>

<script>
// <p>{{ $route.query.iid }}</p>
import DetailNavBar from "./childComp/DetailNavBar.vue";
import DetailSwiper from "./childComp/DetailSwiper.vue";
import DetailBaseInfo from "./childComp/DetailBaseInfo.vue";
import DetailShopInfo from "./childComp/DetailShopInfo.vue";
import DetailGoodsInfo from "./childComp/DetailGoodsInfo.vue";
import GoodsList from "components/content/goods/GoodsList.vue";
import DetailGoodsParam from "./childComp/DetailGoodsParam.vue";
import DetailComment from "./childComp/DetailComment.vue";

import BScroll from "components/content/scroll/BScroll.vue";
import BackTop from "components/content/backTop/BackTop.vue";

import { getGoodsImages, getGoodsList } from "network/detail.js";
import { Goods, Shop, Param } from "common/models.js";

export default {
  name: "Detail",
  components: {
    DetailNavBar,
    DetailSwiper,
    DetailBaseInfo,
    DetailShopInfo,
    DetailGoodsInfo,
    GoodsList,
    DetailGoodsParam,
    DetailComment,
    BScroll,
    BackTop,
  },
  data() {
    return {
      styleImage: [],
      baseGoods: {},
      shop: {},
      detailInfo: {},
      goodsList: [],
      goodsParam: {},
      commentInfo: {},
      isShowBackTop: false, //回到顶部按钮显示
    };
  },
  created() {
    this.getGoodsImages();
    this.getGoodsList();
  },
  methods: {
    //监听滚动事件
    contentScroll(y) {
      // console.log(y);
      this.isShowBackTop = y <= -1000;
    },
    //回到顶部
    goBackTop() {
      // console.log("111");
      this.$refs.bsScroll.scrollToTop();
    },
    //传入商品轮播图片
    getGoodsImages() {
      getGoodsImages(this.$route.query.iid).then((res) => {
        // console.log(res);
        let result = res.result;
        this.styleImage = result.itemInfo.topImages;

        this.baseGoods = new Goods(
          result.itemInfo,
          result.columns,
          result.shopInfo
        );
        this.shop = new Shop(result.shopInfo);

        this.detailInfo = result.detailInfo;

        this.goodsParam = new Param(
          result.itemParams.info,
          result.itemParams.rule
        );

        this.commentInfo = result.rate.list[0];
      });
    },
    getGoodsList() {
      getGoodsList().then((res) => {
        this.goodsList = res.data.list;
      });
    },
  },
  mounted() {
    //监听总线事件
    this.$bus.$on("itemImgLoad", () => {
      this.$refs.bsScroll && this.$refs.bsScroll.refresh();
    });
  },
};
</script>

<style scoped>
.detail {
  position: relative;
  height: 100vh; /*视口高度：100vh相当于100% */
}
.detail-swiper {
  height: 300px;
}
.main-scrollContent {
  height: calc(100% - 93px);
  overflow: hidden;
}
</style>