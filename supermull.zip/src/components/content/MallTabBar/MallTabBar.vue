<template>
  <tab-bar>
    <tar-bar-item path="/main">
      <img slot="item-normal-img" src="~assets/img/tabbar/home.svg" />
      <img slot="item-active-img" src="~assets/img/tabbar/home_active.svg" />
      <span slot="item-text">首页</span>
    </tar-bar-item>
    <tar-bar-item path="/category">
      <img slot="item-normal-img" src="~assets/img/tabbar/profile.svg" />
      <img slot="item-active-img" src="~assets/img/tabbar/profile_active.svg" />
      <span slot="item-text">分类</span>
    </tar-bar-item>
    <tar-bar-item path="/shopcar">
      <img slot="item-normal-img" src="~assets/img/tabbar/home.svg" />
      <img slot="item-active-img" src="~assets/img/tabbar/home_active.svg" />
      <span slot="item-text">购物车</span>
    </tar-bar-item>
    <tar-bar-item path="/mine">
      <img slot="item-normal-img" src="~assets/img/tabbar/profile.svg" />
      <img slot="item-active-img" src="~assets/img/tabbar/profile_active.svg" />
      <span slot="item-text">我的</span>
    </tar-bar-item>
  </tab-bar>
</template>

<script>
import TabBar from "components/common/tabber/TabBar.vue";
import TarBarItem from "components/common/tabber/TarBarItem.vue";
export default {
  components: {
    TarBarItem,
    TabBar,
  },
};
</script>

<style>
</style>