<template>
  <div class="backTop">
    <img src="~assets/img/common/top.png" />
  </div>
</template>

<script>
export default {};
</script>

<style>
.backTop img {
  position: fixed;
  bottom: 60px;
  right: 15px;
  width: 43px;
  height: 43px;
}
</style>