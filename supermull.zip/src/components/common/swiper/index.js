import Swiper from './Swiper.vue';
import SwiperItem from './SwiperItem.vue';

export {
    Swiper,
    SwiperItem,
}